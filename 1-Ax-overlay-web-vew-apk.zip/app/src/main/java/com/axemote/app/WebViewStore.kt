package com.axemote.app

import android.view.View
import android.webkit.WebView

/** Keeps one WebView instance alive while it is moved between the Activity and overlay window. */
object WebViewStore {
    var webView: WebView? = null
    var overlayShowing: Boolean = false

    fun detach(view: View) {
        (view.parent as? android.view.ViewGroup)?.removeView(view)
    }
}
